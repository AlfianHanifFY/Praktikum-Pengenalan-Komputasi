#nama/nim : Alfian Hanif Fitria Yustanto / 19623281
#tanggal : 5 Oktober 2023
#Deskripsi : Program membuat segitiga sebanyak n kali

#kamus
#n : integer
#i : integer

#algoritma

#input
n = 0
while n <= 0:
  n = int(input("Masukkan banyak segitiga : "))

#proses
for i in range(n):
  print("*****",end="")
print("")

for i in range(n):
  print(" *** ",end="")
print("")

for i in range(n):
  print("  *  ",end="")
print("")